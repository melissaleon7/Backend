const express = require('express');
const rutas= express.Router();

rutas.get('/',cliente.get);
rutas.post('/add',cliente.post);